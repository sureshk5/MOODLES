void simpleExample();
