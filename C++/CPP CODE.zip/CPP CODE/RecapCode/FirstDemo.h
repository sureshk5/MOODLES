#pragma once

int firstExample();
