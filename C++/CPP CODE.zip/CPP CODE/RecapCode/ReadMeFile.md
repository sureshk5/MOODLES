#Recap Sessions
