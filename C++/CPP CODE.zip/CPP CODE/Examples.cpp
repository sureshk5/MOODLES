#include<iostream>
#include<string>
using namespace std;
class person{
	public:
		string name;
};
int main(){
	
}
