package notunique;

import javax.servlet.http.HttpServletRequest;

public class DoubleController {

	public String processRequestAndTellREsponse(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pageName="/WEB-INF/fail.html";
		System.out.println("when things are new, go slow");
		String num = request.getParameter("num");
		int i = Integer.parseInt(num.trim());
		if( i != 0)
		{
				pageName="/WEB-INF/result.html";
			
		}
		
		
		return pageName;
		
		
		
	}

}
