package exam.hello;

import java.util.List;

import org.springframework.web.client.RestTemplate;

public class D {

	public static void main(String[] args) {
		// suppose postman goes to post office
		String url ="http://localhost:9900";
		RestTemplate t =new RestTemplate();
		
		  Mobile x = t.getForObject(url+"/pw?x=2",Mobile.class);
		  System.out.println(x.getImeino());
		 
		
		  
		  /*
		
		  List l = t.getForObject(url+"/ms",List.class); 
		  
		  System.out.println(l.size());
		 
		
		  Mobile z =new Mobile(67,77);
		  Mobile q =  t.postForObject("http://localhost:8080/upd", z, Mobile.class);
		  System.out.println(q);
		  
		  
		  
		  */
		 
		
		
		
		
		
		
		
		
		

	}

}
