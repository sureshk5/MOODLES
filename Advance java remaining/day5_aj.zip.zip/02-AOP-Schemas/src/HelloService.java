
public class HelloService {


	
	public void test() {
	
		System.out.println("inside helloservice");
		
	}

}
