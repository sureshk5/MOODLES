
public class HelloService3 {

	
	public void display() {
	
	
		System.out.println("inside display");
		
		
	}

}
