
public class HelloService1 {

	
	public int test2() {
		System.out.println("inside helloservice1");
		return 3;
	}

}
