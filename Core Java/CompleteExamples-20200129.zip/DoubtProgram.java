package basics;

class Vehicle{
	private String name;
	private String eName;
	
	private String getName() {
		return name;
	}
	
	private String getEngineer() {
		return eName;
	}
}



public class DoubtProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
