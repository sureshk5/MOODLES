#!/bin/bash

taskset $2 ./$1& 
taskset $2 ./$1& 
taskset $2 ./$1& 
taskset $2 ./$1& 
