#!/bin/bash

taskset 0x00000001 ./w1& 
taskset 0x00000001 ./w1& 
taskset 0x00000001 ./w1& 
taskset 0x00000001 ./w1 
