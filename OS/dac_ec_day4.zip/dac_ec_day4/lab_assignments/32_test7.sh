#!/bin/bash

sudo -i

sleep 90
