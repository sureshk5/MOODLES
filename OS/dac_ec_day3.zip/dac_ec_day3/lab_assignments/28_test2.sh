#!/bin/bash

#taskset 0x00000001 ./w11 
#taskset 0x00000001 ./w11& 
#taskset 0x00000001 ./w11& 
#taskset 0x00000001 ./w11& 


./w11& 
./w11& 
./w11& 
./w11& 
