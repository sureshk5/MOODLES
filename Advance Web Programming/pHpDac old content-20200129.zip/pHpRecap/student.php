class student{
	$id = 0;
	$name = "";
	$address = "";
	$contact = 0;
	$year = 2019;
}