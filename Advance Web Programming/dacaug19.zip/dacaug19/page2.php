<?php
/*
if(isset($_COOKIE["Userid"]))
{
    echo "You are logged in";
}
else
{
    echo "Cookie not set";
}
*/
session_start();

if(isset($_SESSION["Userid"]))
{
    //echo "You are logged in";
    echo $_SESSION["Userid"];
}
else
{
    echo "Session not set";
}
