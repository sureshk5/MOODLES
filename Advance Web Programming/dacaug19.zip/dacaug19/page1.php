<?php

//setcookie("Userid", "FB123", time()+3600);

session_start();

$_SESSION["Userid"] = "FB123";

