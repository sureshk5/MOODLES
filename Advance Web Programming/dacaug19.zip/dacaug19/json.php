<script>
    var jso = '{"Name":"Anoop","EmpId":271345,"Mobile":["7411","8880"]}';
    p = JSON.parse(jso);
    alert(p.Mobile[1]);
</script>


<?php
/*
$arr = array("Name"=>"Anoop", "EmpId"=>271345, "Mobile"=>array("7411", "8880"));

$json = json_encode($arr);

echo $json;
echo "<br/><br/>";
$obj = json_decode($json);

print_r($obj);
echo "<br/><br/>";
echo $obj->EmpId;
echo "<br/><br/>";
echo $obj->Mobile[1];
 */