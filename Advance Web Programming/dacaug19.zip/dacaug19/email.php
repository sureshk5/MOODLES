<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    
    require 'phpmailer/PHPMailer.php';
    require 'phpmailer/SMTP.php';
    require 'phpmailer/Exception.php';
    
    
    $mail = new PHPMailer();
    
    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                   
        $mail->SMTPAuth   = true;                                 
        $mail->Username   = 'anoopmis@gmail.com';                    
        $mail->Password   = '';                              
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;        
        $mail->Port       = 587;                                    
        
        $mail->setFrom('anoopmis@gmail.com', 'Anoop');
        $mail->addAddress('anoopmis@live.com');     
        //$mail->addAttachment('');    
        
        $mail->isHTML(true);                                  
        $mail->Subject = 'Demo for PHPMailer';
        $mail->Body    = 'Hi, This a demo for DAC in Web Programming Module';
        
        
        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

