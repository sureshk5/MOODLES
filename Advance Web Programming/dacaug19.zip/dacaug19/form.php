<form action="formhandler.php" method="POST" enctype="multipart/form-data">
    <input type="text" name="userid" value="" placeholder="userid" required/>
    <input type="password" name="password" placeholder="password" value="" required/>
    <input type="submit" value="Submit" />
</form>

