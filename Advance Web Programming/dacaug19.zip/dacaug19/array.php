<?php
$emps = array();
$emps[0] = array("Name"=>"Amit", "Age"=>30);
$emps[1] = array("Name"=>"Ashish", "Age"=>20);
$emps[2] = array("Name"=>"Abhishek", "Age"=>40);
$emps[3] = array("Name"=>"Ashutosh", "Age"=>35);

foreach ($emps as $value) {
    foreach ($value as $key => $value1) {
        echo $value1;
        echo "<br/>";
    }
}





