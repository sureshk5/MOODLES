<?php

$xml = simplexml_load_file("emp1.xml");

foreach ($xml as $emp)
{
    echo $emp->NAME;
    echo "<br/><br/>";
}

