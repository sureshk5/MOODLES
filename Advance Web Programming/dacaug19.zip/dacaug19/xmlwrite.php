<?php
$xml = new SimpleXMLElement("<dac/>");
        
$link = mysqli_connect("localhost", "root", "", "dac");
$query = "select * from login";
$result = mysqli_query($link, $query);

while($row = mysqli_fetch_assoc($result))
{
    $login = $xml->addChild("login");
    $login->addAttribute("userid", $row['userid']);
    $login->addChild("password", $row['password']);        
}
$xml->saveXML("login.xml");


