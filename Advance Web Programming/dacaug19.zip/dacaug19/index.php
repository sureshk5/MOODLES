<?php
        echo "Commandline output";
        exec("notepad");        
       ?>

