<?php
$userid = $_POST['userid'];
$password = $_POST['password'];        


$link = mysqli_connect("localhost", "root", "", "dac");

$query = "insert into login values('$userid', '$password')";

mysqli_query($link, $query);

echo "Data Inserted Successfully";
