<script src="jquery.js"></script>
<script>
    function search()
    {
        val = $('#pattern').val();
        if(val.length > 0)
        {
            $.post("search.php",{"pattern":val}, function(data){
                $('#suggestion').html(data).show();
            });
        }
        else
        {
            $('#suggestion').hide();
        }
    }
</script>
<style>
    #suggestion{
        width:200px;
        height: 200px;
        border: 2px solid blue;
        display: none;
    }
    li {margin:0px;padding:5px;background-color: pink;
    list-style: none;}
    li:hover{background-color: red}
    ul {margin: 0px; padding:0px;}
    img {width:25px; height: 25px;}
</style>
<input type="text" id="pattern" onkeyup="search()">
<div id="suggestion"></div>

