<?php

//setcookie("Userid", "FB123", time()-1);

session_start();
session_destroy();
