<?php
include 'db.php';
$link = mysqli_connect($host, $username, $password, $database);

$query = "select * from login";

$result = mysqli_query($link, $query);

echo "<table>";
echo "<tr><th>UserId</th><th>Password</th></tr>";
while ($row = mysqli_fetch_assoc($result))
{
    echo "<tr><td>".$row['userid']."</td><td>".$row['password']."</td></tr>";
}
echo "</table>";