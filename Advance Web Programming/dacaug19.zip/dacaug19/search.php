<?php
$pattern = $_POST['pattern'];
$link = mysqli_connect("localhost", "root", "", "dac");
$query = "select * from login where userid like '%$pattern%'";
$result = mysqli_query($link, $query);
echo "<ul>";
while($row = mysqli_fetch_assoc($result))
{
    echo "<li><img src='img/".$row['userid'].".jpg'/>".$row['userid']."</li>";
}
echo "</ul>";